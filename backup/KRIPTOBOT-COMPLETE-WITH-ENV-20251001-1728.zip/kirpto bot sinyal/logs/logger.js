const fs = require('fs');
const path = require('path');

// Log klasörü kontrolü
const logDir = path.join(__dirname);
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
}

// Log dosyası yolları
const errorLogPath = path.join(logDir, 'error.log');
const eventLogPath = path.join(logDir, 'events.log');

/**
 * Hata loglama fonksiyonu
 */
function logError(error, context = '') {
    const timestamp = new Date().toISOString();
    const errorMessage = error instanceof Error ? error.stack : error;
    const logMessage = `[${timestamp}] ERROR ${context}: ${errorMessage}\n`;
    
    // Console'a yazdır
    console.error(logMessage);
    
    // Dosyaya yaz
    try {
        fs.appendFileSync(errorLogPath, logMessage);
    } catch (writeError) {
        console.error('Log yazma hatası:', writeError);
    }
}

/**
 * Event loglama fonksiyonu
 */
function logEvent(message, context = '') {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] EVENT ${context}: ${message}\n`;
    
    // Console'a yazdır
    console.log(logMessage);
    
    // Dosyaya yaz
    try {
        fs.appendFileSync(eventLogPath, logMessage);
    } catch (writeError) {
        console.error('Log yazma hatası:', writeError);
    }
}

/**
 * Info loglama fonksiyonu
 */
function logInfo(message, context = '') {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] INFO ${context}: ${message}\n`;
    
    // Console'a yazdır
    console.log(logMessage);
    
    // Dosyaya yaz
    try {
        fs.appendFileSync(eventLogPath, logMessage);
    } catch (writeError) {
        console.error('Log yazma hatası:', writeError);
    }
}

module.exports = {
    logError,
    logEvent,
    logInfo
};